from django.urls import path
from .views import CategoryView, ArticleView, AuthorView

urlpatterns = [
    path('categories/', CategoryView.as_view()),       
    path('categories/<int:pk>/', CategoryView.as_view()),  
    path('articles/', ArticleView.as_view()),          
    path('articles/<int:pk>/', ArticleView.as_view()),     
    path('authors/', AuthorView.as_view()),            
    path('authors/<int:pk>/', AuthorView.as_view()),       
]
